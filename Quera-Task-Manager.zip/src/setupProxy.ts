// import { createProxyMiddleware } from "http-proxy-middleware";
// import { Application } from "express"; // Ensure you have `@types/express` installed
// import * as apiUrl from "./config.json";
// export default function setupProxy(app: Application) {
//   app.use(
//     "/",
//     createProxyMiddleware({
//       target: "https://185.8.174.74:8000",
//       changeOrigin: true,
//     })
//   );
// }
